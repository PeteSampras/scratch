# Presenter notes - discussion pages (scrubbed, employer-neutral)

Format: a discussion, not a polished talk. Open `index.html` from the bundle (offline). Walk order: **9 -> 11 -> 12 -> 13 -> 5 -> 4 -> 3 -> 6 -> 7 -> 1 -> 8**, then **10** as the discussion starter; page 2 is an appendix (skip live, keep for questions).
Keys in an archify page: `F` presentation stage (hides the cards: say the PLANNED items and the "At scale" suggestions aloud), `R` route trace, `L` lens, `T` theme, `S` style. Page 10: do not press `F`.
Tags: every box says `LIVE` (runs in the lab today) or `PLANNED` (designed, not running). "At scale" notes are the author's suggestions, not measurements. Products are examples of a category.
Fallbacks: `exports/` in the bundle holds a PNG and a PDF of every diagram page.



---

# Page 9 - Information to action (presenter notes)

Page: `09-info-to-action` (workflow). Framing: a discussion starter, not a polished design.

- Ask first: how does raw information (reports, telemetry, artifacts, requirements) become something useful without a person pulling every lever?
- Click order: press F; start at the three entry points (requirement-driven, scheduled, event or ask driven); follow the shared pipeline left to right: priority queue, enrichment, decision tiers, products, human gate, execution; end on the dashed feedback edge back to requirements.
- Name the two paths out loud. PROACTIVE starts from a question and nobody is paged; REACTIVE starts from an event or an ask. They share every stage after the queue.
- LIVE-TODAY in the lab: triggers by timer and polling, priority queue (priority and aging in the job queue; expiry in the task queue), enrichment, products, the human gate, execution. PLANNED: the tiered decision cascade (the script tier runs in shadow only and acts on nothing), event-driven routing, and automated feedback to requirements (people re-rank asks today).
- Key numbers (lab): 1,478 reports from 73 sources in a week; 1,549 cases to date (2026-10-14): 1,454 are RBA-linked (most were opened directly by the correlation engine before 2026-09-01), about 95 from triage or other paths.
- The cards labelled "At scale (suggestion)" are the author's suggestions, not measurements: for each stage, what breaks at 100x and 10,000x and the category of fix (priority classes, partitioning, backpressure, idempotency, tiered models, ownership routing).
- Close with the question for the room: which stage breaks first for us, and who owns it?

---

# Page 11 presenter notes: how we employ agents, end to end

Page: `11-agent-employment` (workflow). Discussion starter: where in a hyperscale pipeline should a model be allowed to run at all?

- Ask first: of everything that arrives, how much really needs a model, and how much needs a person?
- Click order: press F; start at Sources, follow the top two lanes (ingest routing, then System one levels 1 and 2), drop to the Trigger lane, then the Agent run lane, and finish on the Routed onward node (page 13 covers where output goes).
- Principle to say out loud: each level is cheaper and more repeatable than the next; escalate only when unsure; a model may raise an impact tier, never lower it. If a level is confident, it acts or routes and no agent run happens.
- Be explicit about status. LIVE today: sources into the lake, timers and asks submitting jobs to the orchestrator job queue (priority, aging), persona runs, structured output, onward routing and the human approval gate.
- PLANNED: NiFi ingest routing and StackStorm triggering are designed and drafted, not deployed. Level 1 (impact script) and the small classifier run only in observe-only shadow mode on new vault proposals; the larger classifier is built only if a bake-off justifies it.
- Honest gap: today events do not pass through the decision levels; timers submit the agent job directly. The picture is the target, with the live path shown as "today's trigger".
- Key number: about 30 agents are scheduled today; most runs are timer-triggered.
- Cards labelled "At scale (suggestion)" are the author's suggestions, not measurements.
- Close with: which level would you build first, and who owns the escalation threshold?

---

# Page 12 presenter notes: assembling an agent run

Page: `12-prompt-assembly` (workflow). Discussion starter: what exactly does the model get, and who decided?

- Ask first: when your analysts hand work to a model, is the context a pointer ("go read X") or the payload itself?
- Click order: press F; Select (job and persona profile), Fetch (tool allow-list, lessons and runbooks, context store), Prepare (deterministic scripts, no model), Compose and run, then the result check at top right.
- Process point, say it twice: deterministic prep first. Cost (scripts are nearly free), repeatability (same script, same facts), smaller prompts (extracted fields, not raw logs).
- Lab example: an agent mixed up two data sources in its own ad-hoc query and reported a wrong cadence. The fix was a facts script that runs first and is injected into the prompt, not a request to be more careful.
- Evidence that payload beats pointer: a hint telling the model which runbook to open was followed 1.6 percent of the time (8 of 486); putting the checklist itself in the prompt fixed that.
- LIVE today: persona profile (charter text, tool allow-list, read and write scopes), keyword-matched lessons and runbooks, a facts script for one agent, saved own-state for two more, the prompt hashed per job, a check that output was written.
- PLANNED, said plainly: the context store (a searchable index over lessons, runbooks, skills and scripts) serves human-driven sessions today but is NOT in the agent dispatch path and has no authentication. Persona, skills and memory from it, catalogued pre-gates for every agent, a fixed stable-to-volatile prompt layout, and a check that output cites its context are designed only. Prefix-cache hit rate is unmeasured.
- Cards labelled "At scale (suggestion)" are suggestions, not measurements.

---

# Page 13 presenter notes: agent roster and where output goes

Page: `13-roster-and-outputs` (architecture). Discussion starter: an agent that cannot change anything is only useful if its output lands somewhere that does.

- Ask first: for each analyst role you have, where does its output go, and who is obliged to read it?
- Left column: six persona families, about 30 roles, most on a schedule (the personal and employer-specific helpers are left out). Do not read the list; name the families.
- Middle: output routes. Proposals go to the approval gate (detections, fixes, tuning, batched completion requests); findings and lake rows hold per-domain results; answers, case updates and alerts reach people.
- Right: what the output feeds. Approved detection rules reach the SIEM through the normal deploy pipeline; gaps found become tasks in the queue; hunts are chosen against priority intelligence requirements and visibility RFIs, via the queue, not an automatic trigger.
- Principle: every agent is read-broad and propose-only; nothing changes production without a human approving. Proposals are checked by an adversarial validator agent first.
- Status: everything shown is LIVE today except the action broker (PLANNED), which would execute approved changes with its own audit trail. Today the operator's assistant executes approved items.
- Candid point: the loop is only closed if approved work is built; approved-but-unbuilt age is the metric to watch.
- Cards labelled "At scale (suggestion)" are suggestions, not measurements.

---

# Presenter notes: page 5, proactive intelligence loop

- Start at Requirements and trace left to right: tasks, raw, rows (collection, processing), then Analysis. Message: the requirement decides what we collect, not the other way round.
- Point at Analysis and say two things plug in here: hunts (the box to the right, hypothesis-driven, a negative result is still a result) and RFIs (they arrive at Requirements and are answered in Products).
- Follow Products back to Feedback and up to Requirements: the loop closes only if lessons change the requirements. Today the scoring (source reliability, detection fidelity) is automatic; the arrow is labelled "human re-rank" because changing the requirements is a human step. Say that plainly.
- Contrast lane, bottom-left: reactive triage starts from an alert, not a question. Of 1,549 cases to date (2026-10-14), 1,454 are RBA-linked (most were opened directly by the correlation engine before 2026-09-01); about 95 are not RBA-linked. Reactive agent-decided escalation is rare and costly; its dispositions feed back into rule tuning.
- Key number: 1,478 reports from 73 sources landed in the lake in one week, from 258 feeds plus a handful of MISP feeds (7 days to 2026-10-14). Requirements actors renew weekly; "none observed" is a valid answer.
- PLANNED, say so: automatic retro-hunt of new IOCs against history (today it is ad hoc). Everything drawn is LIVE-TODAY.
- At scale (my suggestion, not measured): requirement duplicates and staleness, tasking volume, analyst/agent capacity, and feedback latency. Give each requirement an owner and an expiry.

---

# Presenter notes: page 4, the ingest tree

- Open with the question: "when something new enters the system, who decides where it ends up?" Root on the left, five source types in the middle column.
- Click order: OSINT (top), vendor report, malware, telemetry, code scan. Say the decider in the card line out loud each time: a script, a rule or an agent, never "the AI".
- Five endings to name: stops at lake/wazuh, case management, action, persona/agent, RFI/task/proposal. Telemetry is the only source drawn with two endings; the cards list the rest.
- Key number: of 1,549 cases to date (2026-10-14), 1,454 are RBA-linked (most were opened directly by the correlation engine before 2026-09-01) (not an agent or human decision), so about 95 are not RBA-linked. Message: most paths end quietly at the lake, on purpose.
- Capability-first: swap the names for your own stack. What you need is a store-everything tier, a cheap decider at each fork, and a human at the last fork.
- Presentation mode (F) hides the cards, so the PLANNED items below are not on screen: say them aloud or exit F.
- PLANNED (say so): automatic retro-hunt of new IOCs, an alert screener, auto-close of known-benign rules, dead-letter queue. All other nodes are LIVE-TODAY.
- At scale (my suggestion, not measured): dedup at the first fork, put a fast classifier before any LLM, and watch the promotion rate for drift.
- Caveat to volunteer: CAPE-to-lake row volume is not verified; RAPTOR dependency-scan output did not reach the lake; a fix is written, deploy not verified.

---

# Page 3 presenter notes: telemetry to lake flow

- Open with the left-to-right stages: sources, collect, decode and rules, write and checkpoint, store and use. Everything on this page is LIVE-TODAY; the v2 changes are only named in the At scale card as PLANNED.
- Route A (click route-a-1 to route-a-5, or use Route Probe host logs to query): endpoint agent, manager with rules, lake writers, Parquet commit, pruned SQL. Key number: about 17M archive rows on a single day.
- Route B (route-b-1 to route-b-4): mirror and GRE taps, Suricata and Zeek, then two paths, the agent to the manager and a buffered Vector path to the lake. Key number: 200,430 sensor rows in the last 24 h (measured).
- Route C (route-c-1, route-c-2): the dedup control point. Writer commits rows, then saves its state. On the evening of 2026-10-14 (US Central) a crash between the two replayed 672,350 rows; the hourly duplicate-ratio check caught it at 1.273.
- Fix to say out loud: checkpoint immediately after commit, read the file time before reading the file, and a regression test that fails on the old code. The lesson: commit plus checkpoint is one logical step.
- Capability first: the lab uses Wazuh, Vector, Iceberg and Trino, but the capability is "collect, normalise, store cheaply, query with pruning, and make writers idempotent". Any equivalent stack works.
- At scale card is the author's suggestion, not a measurement: size for 10x bursts, tier storage, prune every query, and keep a duplicate-ratio check as the safety net.
- Honest caveat: the operator chose to leave the duplicate rows because every consumer reads a trailing two-hour window.

---

# Page 6 - Governance and personas (presenter notes)

Pages: `06-governance` (proposal lifecycle), `06c-tasking` (task and RFI lifecycle), `06b-personas` (roster by function).

- Open with the question: how do you keep 34 AI personas from changing production? Answer: they can only write a proposal.
- Click order on 06-governance: press F, then follow the main path left to right: write proposal, duplicate gate, adversarial validator, approve or deny, check HOLD and build, completion-request, approve completion.
- Stress that completion is itself a proposal: "done" is reviewed by the human, not assumed by the executor.
- The dashed broker node is PLANNED (v2): approvals bound to the request digest and the approver's SSO identity. Everything solid is LIVE-TODAY.
- Key numbers (LIVE-TODAY): 1,551 completed, 70 approved-and-unbuilt, 106 denied, 1,330 validator verdicts, 886 archived tasks.
- On 06c-tasking: every request has an owner, a last-time-of-value and an observable done condition; expiry is visible, never silent; HOLD is exempt from sweeps. The cascade pre-answer state is PLANNED.
- On 06b-personas: 34 personas in 7 groups (6 leads, 7 SOC and intel, 4 red team, 3 identity and cloud, 7 infra, 3 governance, 4 interactive or personal; 3 personal helpers are out of scope). About 30 timers drive them; v2 collapses them into one runner with compiled profiles (PLANNED).
- "At scale" cards are suggestions, not measurements: map lanes onto real teams with separation of duties, tier changes by risk, and watch approved-but-unbuilt age.
- Lead with hand-offs: on 06-governance the first card lists triggers, queues, owners and human gates; say which stages are automated (duplicate gate, validator, sync, reconcile) and which two are human (approve or deny, approve completion).
- Cadences on 06b come from the live timers: most personas run twice a day, some every 2 to 12 h, a few daily or on demand; do not say weekly.
- Duplicate gate is partial: obvious duplicates are blocked, semantic relations only flagged. Cards are hidden in F mode: leave F mode to show triggers, queues and owners.
- The AI executor is the sole executor today; at work that is a platform team with AI assistance.

---

# Page 7 presenter notes: LLM serving and decision cascade

- Top lane is the request path (LIVE-TODAY): trigger, orchestrator queue with priority and aging, context assembly, admission, one shared model service, result check. 32 agent profiles.
- Bottom lane is the cascade: impact script, small classifier, larger classifier, full LLM, human. Say "each tier escalates only when unsure" at every arrow. Tier 1 (shadow-running, not yet a live decider), the two classifier tiers and the decision service are PLANNED (pilot); everything else is LIVE-TODAY.
- Tier 1 is a cheap keyword scan that sets an impact tier. Rule: tier = max(floor, scan); a model may only raise it, never lower it.
- Process point: the small classifier gave the same top answer on every repeat, so each decision can be audited and replayed.
- Pilot result: it decided 68% of 1,400 clean-labelled vault notes at zero errors on one yes/no question (AUC 0.99). One question, one corpus, not yet certified on newer data: do not generalise.
- Be candid about limits: ATT&CK mapping is a shortlist job, not a decision (parent 68.6% right, final exact 43.1%, errors compound).
- Asking the model to judge consequence failed the safety test (2 of 20 serious lessons rated LOW); the deterministic floor passed (0 of 20 held-out) at the cost of over-escalation.
- At scale (author suggestion): triage first means only the unsure remainder pays for the big LLM and reaches a human, so cost and review load fall with the share decided early. Start in shadow mode.

---

# Page 1 presenter notes: capability stack

- Say: twelve capability layers; the lab's tool in each is only one example. Every box is LIVE-TODAY; v2 additions are PLANNED and sit in the cards.
- Click order: follow the data path left to right (network, telemetry, data platform), then down to detection and cases.
- Then the intelligence row: threat intel feeds actor TTPs to the purple layer and extraction work to the local-model layer.
- Bottom row: agents may only propose; governance approves; identity and observability keep an audit trail.
- Key number: 1,454 of 1,549 incident cases are RBA-linked (2026-10-14), mostly engine-opened before 2026-09-01 and not agent decisions.
- Every "At scale" line is the author's suggestion, not a measured fact.
- Keep it about process: what triggers work, how it is queued, which tier decides, where a human approves. Skip the infrastructure details.
- Ask the room: which layer would you build first from scratch? (Suggested answer: telemetry and the lake.)

---

# Page 8 - Replication map (presenter notes)

- Frame: the lab is a pattern, not a product list. Read each row left to right: what we do, what we expect to break, what category to build or buy, who and what it takes.
- Columns 3 to 5 are suggestions for discussion, never measurements; product names are examples of a category.
- Start with the five cross-cutting rows (hunting, RFI handling, proactive requirements, dedup, LLM cost control): these are what this audience asked about.
- Key number for dedup: one replayed log tail wrote 672,350 rows twice and an hourly fidelity check caught it in about an hour; the fix was checkpoint-after-commit plus a regression test.
- Key number for cost: a pilot of the small classifier decided 68 percent of 1,442 notes at zero errors; the cascade is deterministic script, small classifier, larger classifier, full LLM, human.
- Close with the "homelab-only" list: one person in every role, free feeds only, owned GPUs, rebuild instead of redundancy.
- Say what transfers unchanged: capability-first naming, build order, detection as code, propose-only agents behind a human gate.

---

# Page 10 - Discussion: open questions at scale (presenter notes)

Page: `10-discussion-prompts` (architecture with prompt cards). These are the author's brainstorm prompts, not decisions.

- Say up front: no answers on this page; each card is a question, what the lab does today in one line, the scale problem, and two or three candidate approaches.
- Eight themes: intake and priority, proactive requirements and hunting, RFI throughput, automation versus human gates, cheap-first tiers, trust and quality, org and ownership, data governance. Ten prompt cards (Q1 to Q10) sit under the diagram.
- Tags on the themes: LIVE-TODAY = the lab has a working mechanism today; PLANNED = no live tier or owner routing yet (shadow runs only): cheap-first tiers and ownership. Do not press F on this page: it hides the prompt cards; read in normal mode and scroll.
- Suggested order for a 30 minute session: Q6 (who may act alone), Q7 (cheap-first tiers), Q1 (intake), Q3 (requirements), then let the room pick.
- Products appear only as "e.g."; nothing describes any employer's systems.
- Capture each answer as a candidate approach plus an owner; do not try to settle architecture in the room.

---

# Page 2 presenter notes: APPENDIX, reference deployment (lab-specific hardware)

- SKIP THIS PAGE LIVE. Keep it for questions: the audience does not need the operator's hardware.
- If asked: everything here is PLANNED. It is a custom build: two 64-core EPYC sockets, 1 TB RAM, four 64 GB GPUs (256 GB VRAM); parts ETA early Nov 2026, an estimate.
- Key point if asked: the GPUs have no peer-to-peer, so a 4-GPU model crosses sockets through host RAM. Two layouts (TP=4 or two TP=2 stages) are to be benchmarked, not assumed.
- Guest groups: about 8 guests become about 15, split by trust zone; broker, secrets and ingest guests are isolated from agent-run guests.
- Power: roughly 1.9 to 2.2 kW at the wall is an estimate; needs a 200-240 V circuit or two PSUs. A 180 W per-card cap (from a one-card sweep (dev/gpu-power-sweep-results.md), estimate) would save roughly 280 W (estimate) at an estimated 3-7 percent end-to-end cost, not measured.
- Failure domain: one box carries SOC, runtime and inference, so off-box backups and a restore drill matter.
- Capability-first: swap the box for a rack server or reserved cloud GPU pool; the zoning and NUMA reasoning carry over.
